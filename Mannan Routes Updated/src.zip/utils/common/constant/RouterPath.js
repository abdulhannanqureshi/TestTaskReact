export const PUBLIC_ROUTES = {
  LOGIN_PATH: '/login'
}
export const PRIVATE_ROUTES  = {
  DASHBOARD_PATH: '/'
}
