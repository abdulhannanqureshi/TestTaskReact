export interface IUserTokenData {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
}
