export const ApiRoutes = {
  CORPORATE: {
    service: "/corporate",
    url: "",
    method: "GET",
    authenticate: true,
  },
};
