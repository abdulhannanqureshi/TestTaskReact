export const AppRoutes = {
  HOME: "/",
  TABS:"/tabs"
};
