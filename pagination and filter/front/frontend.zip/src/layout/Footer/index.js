import React from "react";

const Footer = () => {
  return (
    <>
      <footer className="footer">
        <p>&copy; Company 2017-2020</p>
      </footer>
    </>
  );
};
export default Footer;
